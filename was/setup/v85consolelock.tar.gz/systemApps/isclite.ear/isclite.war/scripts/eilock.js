function checkUser() {
  if(document.logonForm.j_username.value=="eiauth@events.ihost.com" || document.logonForm.j_username.value=="eiwiauth@gmail.com" || document.logonForm.j_username.value=="C-BCYD897@nomail.relay.ibm.com") {
     alert("Invalid User ID supplied.");
     document.logonForm.action.disabled=true;
     return false;
  } else {
     document.logonForm.action.disabled=false;
     return true;
  }
}

